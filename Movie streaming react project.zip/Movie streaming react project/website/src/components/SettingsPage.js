import React from 'react';
import AboutUs from './AboutUs';
import TermsAndConditions from './TermsAndConditions';
import Settings from './Settings';
import './settingspage.css';

const SettingsPage = () => {
  const [activeTab, setActiveTab] = React.useState('settings'); // Default active tab is 'about'

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  let content;

  switch (activeTab) {
    case 'settings':
      content = <Settings />;
      break;
    case 'about':
      content = <AboutUs />;
      break;
    case 'terms':
      content = <TermsAndConditions />;
      break;
    default:
      content = <Settings />; // Default to 'About Us' page
      break;
  }

  return (
    <div className="cont">
      <h1 className="setlabel">Cine Wave Settings</h1>
      <nav className="navig">
        <ul>
          <li>
          <button onClick={() => handleTabClick('settings')}>Settings</button>
          </li>
          <li>
            <button onClick={() => handleTabClick('terms')}>Terms and Conditions</button>
          </li>
          <li>
            <button onClick={() => handleTabClick('about')}>About Us</button>
          </li>
        </ul>
      </nav>

      {content}
    </div>
  );
};

export default SettingsPage;
