// MainContent.js
import React from 'react';
import Nav from './components/Nav';
import Banner from './components/Banner';
import Row from './components/Row';
import requests from './components/requests';

function MainContent() {
  return (
    <div>
      <Nav />
      <Banner />
      <Row title="The Originals" fetchUrl={requests.fetchNetflixOriginals}
      isLargeRow
      />
      <Row title="Trending Now" fetchUrl={requests.fetchTrending}/>
      <Row title="Top Rated" fetchUrl={requests.fetchTopRated}/>
      <Row title="Action movies" fetchUrl={requests.fetchActionMovies}/>       
      <Row title="Comedy Movies" fetchUrl={requests.fetchComedyMovies}/>       
      <Row title="Romantic Movies" fetchUrl={requests.fetchRomanticMovies}/>       
      <Row title="Horror Movies" fetchUrl={requests.fetchHorrorMovies}/>       
      <Row title="Documentaries" fetchUrl={requests.fetchDocumentaries}/>
    </div>
  );
}

export default MainContent;
