import React from 'react';

const AboutUs = () => {
  const largeFontSize = { fontSize: '1.5rem' }; // Adjust the size as needed

  return (
    <div>
      <h2>About Us</h2>
      <p style={largeFontSize}>
        Welcome to <strong>Cine Wave</strong>, your ultimate destination for a cinematic journey like no other. We are not just a movie streaming website; we are the heartbeat of movie enthusiasts, a platform designed to bring the magic of the silver screen right to your fingertips.
      </p>

      <p style={largeFontSize}><strong>Our Story</strong></p>
      <p style={largeFontSize}>
        At Cine Wave, we believe in the transformative power of storytelling through film. Our journey began with a group of passionate cinephiles who shared a common dream: to make the world of movies accessible to everyone, anytime, and anywhere. With this vision in mind, we embarked on a mission to create a space where the love for cinema knows no boundaries.
      </p>

      <p style={largeFontSize}><strong>What Sets Us Apart</strong></p>
      <ol>
        <li style={largeFontSize}><strong>Vast Library of Content</strong>: Our extensive library boasts a wide range of movies, from timeless classics to the latest blockbusters. Whether you're into drama, action, romance, or documentary, we've got something for every taste.</li>
        <li style={largeFontSize}><strong>User-Friendly Interface</strong>: We've designed our platform with you in mind. Enjoy a seamless and intuitive browsing experience that makes discovering your favorite films a breeze.</li>
        <li style={largeFontSize}><strong>High-Quality Streaming</strong>: Immerse yourself in the world of cinema with stunning HD and 4K streaming quality. We believe that every frame should be a visual delight.</li>
        <li style={largeFontSize}><strong>Personalized Recommendations</strong>: Our advanced recommendation engine ensures that you never run out of great movies to watch. Discover hidden gems tailored just for you.</li>
        <li style={largeFontSize}><strong>Multi-Device Access</strong>: Whether you're at home, on the go, or even abroad, Cine Wave is accessible on multiple devices, including smartphones, tablets, smart TVs, and desktops.</li>
        <li style={largeFontSize}><strong>Original Content</strong>: Stay tuned for our exclusive original productions, where we collaborate with talented filmmakers to create unique cinematic experiences you won't find anywhere else.</li>
      </ol>

      <p style={largeFontSize}><strong>Our Commitment</strong></p>
      <p style={largeFontSize}>
        At Cine Wave, we are committed to fostering a global community of movie lovers. We believe that the world is united by the universal language of film, and we aim to celebrate and share this art form with enthusiasts from every corner of the globe. We also take pride in promoting diversity in storytelling, ensuring that voices from all backgrounds are heard and appreciated.
      </p>

      <p style={largeFontSize}><strong>Join the Cine Wave Family</strong></p>
      <p style={largeFontSize}>
        Whether you're a casual moviegoer or a die-hard cinephile, we invite you to join our ever-growing Cine Wave family. Explore, connect, and embark on a cinematic adventure like never before. Let's ride the wave of storytelling together.
      </p>

      <p style={largeFontSize}>Thank you for choosing Cine Wave. <em>Lights, camera, action!</em></p>
    </div>
  );
};

export default AboutUs;
