import React, { useState } from 'react';
import logo from './cwlogo.png';
import avatar from './person.png';
import './Nav.css';

function Nav() {
  const [show, handleShow] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleScroll = () => {
    if (window.scrollY > 100) {
      handleShow(true);
    } else {
      handleShow(false);
    }
  };

  const toggleSettings = () => {
    setIsSettingsOpen(!isSettingsOpen);
  };

  const handleSignOut = () => {
    // Add logic to sign out here, e.g., clearing authentication token or state.
    // After signing out, redirect to the login page using window.location.href.
    // For example:
    window.location.href = '/login';
  };

  React.useEffect(() => {
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className={`nav ${show && 'nav__black'}`}>
      <img className='nav__logo' src={logo} alt='website logo' />
      <div className='nav__settings' onClick={toggleSettings}>
        Sign Out
        {isSettingsOpen && (
          <div className={`nav__settingsMenu ${isSettingsOpen ? 'active' : ''}`}>
            <button onClick={handleSignOut}>Sign out</button>
          </div>
        )}
      </div>
      <a href="/login"> {/* Use anchor tag to navigate */}
        <img className='nav__avatar' src={avatar} alt='website avatar' />
      </a>
    </div>
  );
}

export default Nav;
