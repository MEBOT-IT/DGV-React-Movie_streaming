import React, { useState } from 'react';
import './Login.css';

function Login(props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLogin, setIsLogin] = useState(true); // Use state to toggle between login and sign-in

  const handleFormToggle = () => {
    setIsLogin(!isLogin); // Toggle between login and sign-in
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Add authentication logic here (e.g., API request).

    // Assuming authentication is successful, call onLogin with true:
    props.onLogin(true);
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>{isLogin ? 'Login' : 'Sign In'}</h2>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">{isLogin ? 'Login' : 'Sign In'}</button>
      </form>
      <div className="toggle-button">
        <button onClick={handleFormToggle}>
          {isLogin ? 'Switch to Sign In' : 'Switch to Login'}
        </button>
      </div>
    </div>
  );
}

export default Login;
