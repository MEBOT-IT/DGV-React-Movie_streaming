import React from 'react';

const TermsAndConditions = () => {
  const largeFontSize = { fontSize: '1.5rem' }; // Adjust the size as needed

  return (
    <div>
      <h2>Terms and Conditions</h2>
      <p style={largeFontSize}>
        Welcome to <strong>Cine Wave</strong>. These terms and conditions outline the rules and regulations for the use of our movie streaming platform.
      </p>

      <p style={largeFontSize}><strong>1. Acceptance of Terms</strong></p>
      <p style={largeFontSize}>
        By accessing or using Cine Wave, you agree to be bound by these terms and conditions. If you disagree with any part of these terms, please do not use our services.
      </p>

      <p style={largeFontSize}><strong>2. User Responsibilities</strong></p>
      <ul>
        <li style={largeFontSize}>You are responsible for maintaining the confidentiality of your account and password.</li>
        <li style={largeFontSize}>You must not use Cine Wave for any illegal or unauthorized purpose.</li>
        <li style={largeFontSize}>You agree not to reproduce, duplicate, copy, or sell any part of our content without proper authorization.</li>
      </ul>

      <p style={largeFontSize}><strong>3. Content Usage</strong></p>
      <p style={largeFontSize}>
        All content on Cine Wave is for personal and non-commercial use. Any use of our content for commercial purposes requires written consent.
      </p>

      <p style={largeFontSize}><strong>4. Termination</strong></p>
      <p style={largeFontSize}>
        We reserve the right to terminate or suspend your account and access to Cine Wave at our discretion, without notice, for any violation of these terms and conditions.
      </p>

      <p style={largeFontSize}><strong>5. Changes to Terms</strong></p>
      <p style={largeFontSize}>
        We may revise these terms and conditions at any time without prior notice. By using Cine Wave, you agree to be bound by the latest version of these terms.
      </p>

      <p style={largeFontSize}><strong>6. Contact Information</strong></p>
      <p style={largeFontSize}>
        If you have any questions or concerns about these terms and conditions, please contact us at support@cinewave.com.
      </p>

      <p style={largeFontSize}>
        Thank you for reading and abiding by our terms and conditions. We hope you enjoy your experience with Cine Wave!
      </p>
    </div>
  );
};

export default TermsAndConditions;
