import React, { useState, useEffect } from 'react';
import axios from './axios';
import './Row.css';
import YouTube from 'react-youtube';
import movieTrailer from 'movie-trailer';

function Row({ title, fetchUrl, isLargeRow }) {
  const [movies, setMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [trailerUrl, setTrailerUrl] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    async function fetchData() {
      const request = await axios.get(fetchUrl);
      setMovies(request.data.results);
      return request;
    }

    fetchData();
  }, [fetchUrl]);

  const openModal = (movie) => {
    setSelectedMovie(movie);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedMovie(null);
    setIsModalOpen(false);
    setTrailerUrl('');
  };

  const opts = {
    height: '390',
    width: '100%',
    playerVars: {
      autoplay: 1,
    },
  };

  const handleClick = async (movie) => {
    try {
      const url = await movieTrailer(movie?.name || '');
      const urlParams = new URLSearchParams(new URL(url).search);
      setTrailerUrl(urlParams.get('v'));
    } catch (error) {
      console.error(error);
      setTrailerUrl(''); // Clear trailer URL if an error occurs
    }
  };

  const handleSearch = (e) => {
    e.preventDefault(); // Prevents the form from submitting and reloading the page
    handleClick({ name: searchTerm });
  };

  return (
    <div className="row">
      <h2>{title}</h2>

      {/* Search bar */}
      <form onSubmit={handleSearch} className='search__bar'>
        <input
          type="text"
          placeholder="Search for a movie..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      <div className="row__posters">
        {movies.map((movie) => (
          <div key={movie.id}>
            <img
              className={`row__poster ${isLargeRow && 'row__posterLarge'}`}
              onClick={() => handleClick(movie)}
              src={`https://image.tmdb.org/t/p/w500${
                isLargeRow ? movie.poster_path : movie.backdrop_path
              }`}
              alt={movie.name}
            />
            <p className="movie__name">{movie.name}</p> {/* Add this line */}
          </div>
        ))}
      </div>

     

      {/* Trailer */}
      {trailerUrl && <YouTube videoId={trailerUrl} opts={opts} />}
    </div>
  );
}

export default Row;
