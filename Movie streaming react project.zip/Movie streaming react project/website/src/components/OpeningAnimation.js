import React, { useEffect, useState } from 'react';
import './OpeningAnimation.css'; // Create this CSS file for styling
import logo from './clapperboard.png';


const OpeningAnimation = () => {
  const [animationFinished, setAnimationFinished] = useState(false);

  useEffect(() => {
    // Simulate an asynchronous operation (e.g., loading data or assets)
    setTimeout(() => {
      setAnimationFinished(true);
    }, 3000); // Adjust the duration as needed

    // Cleanup when the component unmounts
    return () => {
      // Clear any timers or resources if necessary
    };
  }, []);

  return (
    <div className={`opening-animation ${animationFinished ? 'hidden' : ''}`}>
      
      <img
        className="opening-image"
        src={logo}
        alt="Opening Image"
      />
    </div>
  );
};

export default OpeningAnimation;
