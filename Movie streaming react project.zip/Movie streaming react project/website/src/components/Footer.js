import React from 'react';
import './footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h3>About Cine Wave</h3>
            <p>
              Cine Wave is your ultimate destination for streaming the latest
              and greatest movies. Join us for an unforgettable cinematic
              experience.
            </p>
          </div>
          <div className="col-md-4">
            <h3>Quick Links</h3>
            <ul>
              <li>
                <a href="/movies">Home</a>
              </li>
              <li>
                <a href="/movies">Movies</a>
              </li>
              <li>
                <a href="/movies">TV Shows</a>
              </li>
              <li>
                <a href="/contact">Contact</a>
              </li>
            </ul>
          </div>
          <div className="col-md-4">
  <h3>Connect with Us</h3>
  <ul className="social-icons">
    <li>
      <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer">
        <i className="fa fa-facebook"></i> Facebook
      </a>
    </li>
    <li>
      <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer">
        <i className="fa fa-twitter"></i> Twitter
      </a>
    </li>
    <li>
      <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">
        <i className="fa fa-instagram"></i> Instagram
      </a>
    </li>
  </ul>
</div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;
