import React, { useState } from 'react';

const Settings = () => {
  // Dummy settings options
  const [notification, setNotification] = useState(true);
  const [language, setLanguage] = useState('English');

  return (
    <div>
      <h2>Settings</h2>
      <div>
        <label style={{ marginRight: '10px' }}>Receive Notifications</label>
        <input
          type="checkbox"
          checked={notification}
          onChange={() => setNotification(!notification)}
        />
      </div>
      <div>
        <label style={{ marginRight: '10px' }}>Language:</label>
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
        >
          <option value="English">English</option>
          <option value="Spanish">Spanish</option>
          <option value="French">French</option>
        </select>
      </div>
    </div>
  );
};

export default Settings;
