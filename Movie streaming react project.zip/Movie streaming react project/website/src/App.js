import React, { useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom'; // Import BrowserRouter as Router
import './App.css';
import Row from './components/Row';
import requests from './components/requests';
import Banner from './components/Banner';
import Nav from './components/Nav';
import Login from './components/Login';
import OpeningAnimation from './components/OpeningAnimation';
import SettingsPage from './components/SettingsPage'; 
import Footer from './components/Footer';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Function to set authenticated state
  const handleAuthentication = (status) => {
    setIsAuthenticated(status);
  };

  return (
    <Router> {/* Wrap your entire app with Router */}
      <div className="App">
        <OpeningAnimation />
        {isAuthenticated ? (
          <>
            <Nav />
            <Banner />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />

            <Row title="The Originals" fetchUrl={requests.fetchNetflixOriginals} isLargeRow/>
            <Row title="Trending Now" fetchUrl={requests.fetchTrending} />
            <Row title="Top Rated" fetchUrl={requests.fetchTopRated} />
            <Row title="Action movies" fetchUrl={requests.fetchActionMovies} />
            <Row title="Comedy Movies" fetchUrl={requests.fetchComedyMovies} />
            <Row title="Romantic Movies" fetchUrl={requests.fetchRomanticMovies}/>
            <Row title="Horror Movies" fetchUrl={requests.fetchHorrorMovies} />
            <Row title="Documentaries" fetchUrl={requests.fetchDocumentaries} />

            <SettingsPage /> 
            <Footer />
          </>
        ) : (
          <Login onLogin={handleAuthentication} />
        )}
      </div>
    </Router>
  );
}

export default App;
